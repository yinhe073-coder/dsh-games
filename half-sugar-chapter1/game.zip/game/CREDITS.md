# 半糖心动 · Half-Sweet Crush — 署名与许可（CREDITS）

本文件与游戏内 About 页、itch.io 页面文案保持一致。发布时不得删除本署名。

## 故事与脚本
原创（本项目）。角色与剧情为虚构。

## 画面
AI 生成（火山方舟 · 豆包 Seedream 4.0）。复用既有生成图，当前随包图像为 JPEG。本包未新增付费生成。
说明：AI 生成不等于取得第三方相似性授权；如需商用扩大，请自行复核平台与法律要求。

## 音乐（第三方，必须署名）
- "Carefree" — Kevin MacLeod (incompetech.com)，CC BY 4.0
- "Touching Story" — Kevin MacLeod (incompetech.com)，CC BY 4.0
- "Covert Affair" — Kevin MacLeod (incompetech.com)，CC BY 4.0

许可全文：https://creativecommons.org/licenses/by/4.0/
使用方式：按原文件作为背景音乐使用，未作改编。署名与许可链接须随作品保留。

## 字体
Noto Sans CJK SC — SIL Open Font License 1.1
文件：vendor/NotoSansCJKsc-Regular.otf（随工程提供）

## 引擎
Ren'Py 8.3.6 — MIT 及第三方许可（https://www.renpy.org/）；完整许可见随包 licenses/RenPy-LICENSE.txt。

## 音效
impact.wav：程序生成（本地合成，无第三方来源）。

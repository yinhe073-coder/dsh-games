# 默认语言（None）的界面字符串中文化。未列出的回落英文，不阻塞运行。
translate None strings:
    old "Start"
    new "开始游戏"

    old "Load"
    new "读取存档"

    old "Save"
    new "保存进度"

    old "Preferences"
    new "设置"

    old "About"
    new "关于本作"

    old "Help"
    new "帮助"

    old "Quit"
    new "退出"

    old "Return"
    new "返回"

    old "History"
    new "历史记录"

    old "Skip"
    new "快进"

    old "Auto"
    new "自动"

    old "Q.Save"
    new "快速保存"

    old "Q.Load"
    new "快速读取"

    old "Main Menu"
    new "返回主菜单"

    old "End Replay"
    new "结束回放"

    old "Are you sure?"
    new "确定吗？"

    old "Yes"
    new "是"

    old "No"
    new "否"

    old "Are you sure you want to quit?"
    new "确定要退出吗？"

    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "确定返回主菜单吗？\n未保存的进度会丢失。"

    old "Are you sure you want to end the replay?"
    new "确定结束回放吗？"

    old "Are you sure you want to delete this save?"
    new "确定删除这个存档吗？"

    old "Are you sure you want to overwrite your save?"
    new "确定覆盖这个存档吗？"

    old "Skipping"
    new "快进中"

    old "Version [config.version!t]\n"
    new "版本 [config.version!t]\n"

    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "使用 {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only] 制作。\n\n[renpy.license!t]"

    old "Page {}"
    new "第 {} 页"

    old "Automatic saves"
    new "自动存档"

    old "Quick saves"
    new "快速存档"

    old "Display"
    new "显示"

    old "Window"
    new "窗口"

    old "Fullscreen"
    new "全屏"

    old "Rollback Side"
    new "回退侧"

    old "Disable"
    new "禁用"

    old "Left"
    new "左"

    old "Right"
    new "右"

    old "Unseen Text"
    new "未读文本"

    old "After Choices"
    new "选项之后"

    old "Transitions"
    new "转场"

    old "Text Speed"
    new "文字速度"

    old "Auto-Forward Time"
    new "自动前进时间"

    old "Music Volume"
    new "音乐音量"

    old "Sound Volume"
    new "音效音量"

    old "Test"
    new "试听"

    old "Voice Volume"
    new "语音音量"

    old "Mute All"
    new "全部静音"

    old "The dialogue history is empty."
    new "还没有对话记录。"

    old "Keyboard"
    new "键盘"

    old "Mouse"
    new "鼠标"

    old "Gamepad"
    new "手柄"

    old "Enter"
    new "回车"

    old "Advances dialogue and activates the interface."
    new "推进对话 / 确认界面。"

    old "Space"
    new "空格"

    old "Advances dialogue without selecting choices."
    new "推进对话（不选择选项）。"

    old "Arrow Keys"
    new "方向键"

    old "Navigate the interface."
    new "在界面中移动。"

    old "Escape"
    new "Esc"

    old "Accesses the game menu."
    new "打开游戏菜单。"

    old "Ctrl"
    new "Ctrl"

    old "Skips dialogue while held down."
    new "按住时快进对话。"

    old "Tab"
    new "Tab"

    old "Toggles dialogue skipping."
    new "切换快进。"

    old "Page Up"
    new "Page Up"

    old "Rolls back to earlier dialogue."
    new "回退到之前的对话。"

    old "Page Down"
    new "Page Down"

    old "Rolls forward to later dialogue."
    new "前进到之后的对话。"

    old "Hides the user interface."
    new "隐藏界面。"

    old "Takes a screenshot."
    new "截图。"

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "切换辅助朗读。"

    old "Opens the accessibility menu."
    new "打开无障碍菜单。"

    old "Left Click"
    new "左键"

    old "Middle Click"
    new "中键"

    old "Right Click"
    new "右键"

    old "Mouse Wheel Up"
    new "滚轮上"

    old "Mouse Wheel Down"
    new "滚轮下"

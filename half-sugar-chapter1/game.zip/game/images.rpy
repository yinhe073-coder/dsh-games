# 图片资源声明（竖屏自适应版本：统一 cover 填充 720x1280 舞台）
# 仅改填充方式，不改美术资源本身；原横屏 build 不受影响。

init python:
    def _hs_cover(path):
        return Transform(path, fit="cover", xysize=(720, 1280))

image cover_art = _hs_cover("images/cover.jpg")

image cg1 = _hs_cover("images/cg1_morning.jpg")
image cg2 = _hs_cover("images/cg2_running.jpg")
image cg3 = _hs_cover("images/cg3_collision.jpg")
image cg4 = _hs_cover("images/cg4_elevator.jpg")
image cg5 = _hs_cover("images/cg5_meeting.jpg")
image cg6 = _hs_cover("images/cg6_sunset.jpg")
image cg7 = _hs_cover("images/cg7_coffee.jpg")
image cg8 = _hs_cover("images/cg8_photo.jpg")
image cg9 = _hs_cover("images/cg9_night.jpg")

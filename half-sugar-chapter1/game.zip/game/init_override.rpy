# 工程覆盖配置：在模板 gui/options 初始化完成后统一生效（避免与 define 冲突）
# 由 tools/build.ps1 / build-r3.ps1 复制到 vn/game/init_override.rpy
# 说明：gui.about（署名/许可）放在 options.rpy，避免同一变量两处 define。

init 100 python:
    config.name = "半糖心动"
    config.version = "0.1.0"
    config.save_directory = "half-sugar-crush"
    config.console = False
    gui.accent_color = "#e892b8"
    gui.idle_color = "#eeeeee"
    gui.button_text_idle_color = "#eeeeee"
    gui.hover_color = "#ffd2e5"
    gui.button_text_hover_color = "#ffd2e5"
    gui.game_menu_background = "images/cg9_night.jpg"
    gui.main_menu_background = "images/menu-bg.jpg"

    # 构建产物命名（itch.io 打包用）
    build.name = "HalfSweetCrush"
    build.directory_name = "half-sugar-crush"
    build.version = "0.1.0"
    build.executable_name = "HalfSweetCrush"

    # 中文字体（Noto Sans CJK SC，SIL OFL 1.1 可商用；由构建脚本复制到 game/fonts/）
    gui.text_font = "fonts/NotoSansCJKsc-Regular.otf"
    gui.name_text_font = "fonts/NotoSansCJKsc-Regular.otf"
    gui.interface_text_font = "fonts/NotoSansCJKsc-Regular.otf"
    gui.button_text_font = "fonts/NotoSansCJKsc-Regular.otf"
    gui.choice_button_text_font = "fonts/NotoSansCJKsc-Regular.otf"
    gui.label_text_font = "fonts/NotoSansCJKsc-Regular.otf"
    gui.notify_text_font = "fonts/NotoSansCJKsc-Regular.otf"

# ---- 竖屏自适应版本（0.2.0-portrait-r1）追加：版本号与菜单背景 cover 填充 ----
init 110 python:
    config.version = "0.2.0-portrait-r1"
    build.version = "0.2.0-portrait-r1"
    gui.main_menu_background = Transform("images/menu-bg.jpg", fit="cover", xysize=(720, 1280))
    gui.game_menu_background = Transform("images/cg9_night.jpg", fit="cover", xysize=(720, 1280))
